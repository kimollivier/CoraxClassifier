# version: 3.1
def classFactory(iface):
    from .CoraxImageVideoInspector import CoraxImageVideoInspector
    return CoraxImageVideoInspector(iface)

