def classFactory(iface):
    from .CoraxImageVideoInspector import CoraxImageVideoInspectorPlugin
    return CoraxImageVideoInspectorPlugin(iface)
