# version: 3.5
def classFactory(iface):
    from .CoraxClassifier import CoraxClassifier
    return CoraxClassifier(iface)

