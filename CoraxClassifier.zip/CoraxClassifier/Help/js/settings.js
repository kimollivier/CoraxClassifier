﻿var whSettings = {
	highlightSearchWords : true,
	highlightSearchWordsSingleColor : false,
	tocOnlyExpandSingleHeading : false,
	tocAutoExpandOnActivate : false,
	tocAtimateExpandingCollapsingDuration : 200,
	indexFile : 'index.htm'
}